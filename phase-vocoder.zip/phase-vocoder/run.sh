#!/bin/bash
python3 phase_vocoder.py $1 $2 $3

