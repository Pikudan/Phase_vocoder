#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/python
import sys
from IPython.display import display,Audio
from numpy.fft import fft
from numpy.fft import ifft
import soundfile as sf
import numpy as np
import math

def main(path_input_file, path_output_file, ts_ratio):
    ts_ratio = float(ts_ratio)
    if ts_ratio <= 0:
        print ("Error. Don't positive time stretch ratio.")
        sys.exit(1)
    ts_ratio = 1 / ts_ratio
    #load audio
    sigin, fs = sf.read(path_input_file)
 
    #input audio size
    Lin = sigin.size

    #fs = 22050 choose a frame size of 512 samples for optimal results
    #in article  fs= 48000 samples/sec, frame size of 1024 samples
    #75% - 512 * 0.25 = 128
    N = 512
    H = 128
    #output audio size
    Lout = int(Lin / ts_ratio + N)

    # signal blocks
    phi  = np.zeros(N)
    out = np.zeros(N, dtype=complex)
    sigout = np.zeros(Lout)
    window = np.hanning(N)
    index_output = 0
    index_input = 0
    while index_input < Lin - (N + H):

        index = int(index_input)
    
        # take the spectra of two consecutive windows     
        spec1 =  fft(window * sigin[index: index + N])
        spec2 =  fft(window * sigin[index + H: index + N + H])
        # phase difference
        phi += (np.angle(spec2) - np.angle(spec1))
    
        # bring the phase back to between pi and -pi    
        phi = ((-phi + np.pi) % (2.0 * np.pi) - np.pi) * -1.0       
    
        out.real, out.imag = np.cos(phi), np.sin(phi)
    
        # inverse FFT     
        sigout[index_output: index_output + N] += window * ifft(out * abs(spec2)).real
    
        index_output += H
        index_input += H * ts_ratio
    
    sf.write(path_output_file, sigout, fs)
    
    
if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Error. Not enough parameters.")
        sys.exit(1)
    if len (sys.argv) > 4:
        print("Error. Too many parameters.")
        sys.exit(1)
    path_input_file = sys.argv[1]
    path_output_file = sys.argv[2]
    ts_ratio = sys.argv[3]
    main(path_input_file, path_output_file, ts_ratio)
